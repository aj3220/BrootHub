---
title: "AGB"
---
ℹ️ **🇩🇪 Hinweis (Demo-Seite)**

> Dies ist **keine gewerbliche Website** und dient ausschließlich als **Demonstrations- und Beispielprojekt** für ein Hugo Theme.  
> Es besteht **keine Impressumspflicht gemäß § 5 TMG**.  
> Die darunter stehenden Angaben sind **vorgefertigte Templates**.  
> Zur Kontaktaufnahme besuchen Sie bitte das [GitHub-Profil](https://github.com/Hin7zer). 

ℹ️ **🇺🇸 Notice (Demo Website)**

> This is **not a commercial website** and is provided solely as a **demonstration and example project** for a Hugo theme.  
> Therefore, **no legal notice is required under § 5 TMG (Germany)**.  
> This theme is developed under **German legal requirements**, therefore the demo website and its legal sections are primarily provided in **German**.  
>The following information is **pre-filled template content** for demonstration purposes.  
>For contact, please visit [GitHub profile](https://github.com/Hin7zer).


{{< de/kontakt >}}
{{< de/agb >}}