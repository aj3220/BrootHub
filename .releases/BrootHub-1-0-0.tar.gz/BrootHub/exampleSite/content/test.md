---
title: "Test"
---
# 📬 Kontakt

Sie haben Fragen, ein technisches Anliegen oder benötigen Unterstützung?  
Wir freuen uns auf Ihre Nachricht!
Das ist ein Link nach [placeholder]({{< ref "placeholder" >}})

<center>{{< button_load-external-url-as-iframe url="https://hin7zer.github.io/BrootHub/" button_title="Button Text" overlay_title="Externe Seite wird dargestellt" >}}</center>

{{< button_load-external-iframe "Externe Inhalte laden" >}}
<iframe aria-label='Kontaktanfrage bei IT-SEEDS' frameborder="0" style="height:500px;width:99%;border:none;" src='https://forms.zohopublic.eu/itseedsproto1/form/TechHelpForm/formperma/WKmaWZsTl7LS8YpZegDuC43Wb5R9qpEbC8q9E9_N1mg'></iframe>
{{< /button_load-external-iframe >}}

